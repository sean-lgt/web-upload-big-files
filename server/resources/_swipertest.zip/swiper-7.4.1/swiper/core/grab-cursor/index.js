import setGrabCursor from './setGrabCursor.js';
import unsetGrabCursor from './unsetGrabCursor.js';
export default {
  setGrabCursor,
  unsetGrabCursor
};